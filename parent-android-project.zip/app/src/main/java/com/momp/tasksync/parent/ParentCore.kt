package com.momp.tasksync.parent

import android.content.Context
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

data class Member(
    val id: String,
    val name: String,
    val online: Boolean
)

data class ParentTask(
    val id: String,
    val title: String,
    val due: Long,
    val status: String,
    val nudge: Long,
    val assignee: String
)

fun parseMembers(json: String?): List<Member> {
    if (json.isNullOrBlank() || json == "null") return emptyList()
    val out = ArrayList<Member>()
    try {
        val o = JSONObject(json)
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val m = o.optJSONObject(k) ?: continue
            out.add(
                Member(
                    id = k,
                    name = m.optString("name", k),
                    online = m.optBoolean("online", false)
                )
            )
        }
    } catch (_: Exception) {}
    return out.sortedBy { it.name }
}

fun parseParentTasks(json: String?): List<ParentTask> {
    if (json.isNullOrBlank() || json == "null") return emptyList()
    val out = ArrayList<ParentTask>()
    try {
        val o = JSONObject(json)
        val keys = o.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val t = o.optJSONObject(k) ?: continue
            out.add(
                ParentTask(
                    id = k,
                    title = t.optString("title", ""),
                    due = t.optLong("due", 0L),
                    status = t.optString("status", "pending"),
                    nudge = t.optLong("nudge", 0L),
                    assignee = t.optString("assignee", "")
                )
            )
        }
    } catch (_: Exception) {}
    return out.sortedByDescending { it.due }
}

object ParentStore {
    private fun p(c: Context) = c.getSharedPreferences("parent_s", Context.MODE_PRIVATE)
    fun room(c: Context): String = p(c).getString("room", "") ?: ""
    fun setRoom(c: Context, r: String) {
        p(c).edit().putString("room", r).apply()
    }
}

object ParentApi {
    const val BASE = "https://momp-37901-default-rtdb.firebaseio.com"

    @Volatile
    private var cur: HttpURLConnection? = null

    fun get(path: String): String? {
        return try {
            val c = URL("$BASE/$path.json").openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 10000
            val s = c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            s
        } catch (_: Exception) {
            null
        }
    }

    fun send(path: String, method: String, body: String? = null): Boolean {
        return try {
            val c = URL("$BASE/$path.json").openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 10000
            if (method == "PATCH") {
                c.requestMethod = "POST"
                c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
            } else {
                c.requestMethod = method
            }
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val ok = c.responseCode in 200..299
            c.disconnect()
            ok
        } catch (_: Exception) {
            false
        }
    }

    fun stream(path: String, onEvent: () -> Unit, stop: () -> Boolean) {
        while (!stop()) {
            try {
                val c = URL("$BASE/$path.json").openConnection() as HttpURLConnection
                c.setRequestProperty("Accept", "text/event-stream")
                c.connectTimeout = 10000
                c.readTimeout = 70000
                cur = c
                BufferedReader(InputStreamReader(c.inputStream)).use { r ->
                    var line = r.readLine()
                    while (line != null && !stop()) {
                        if (line.startsWith("event: put") || line.startsWith("event: patch")) {
                            onEvent()
                        }
                        line = r.readLine()
                    }
                }
            } catch (_: Exception) {}
            if (stop()) break
            try {
                Thread.sleep(3000)
            } catch (_: Exception) {}
        }
    }

    fun stopStream() {
        try {
            cur?.disconnect()
        } catch (_: Exception) {}
    }

    fun randomCode(len: Int = 6): String {
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        return (1..len).map { chars.random() }.joinToString("")
    }

    fun newTaskId(): String {
        val chars = "abcdefghijklmnopqrstuvwxyz0123456789"
        return "t" + System.currentTimeMillis() + "_" + (1..4).map { chars.random() }.joinToString("")
    }
}
