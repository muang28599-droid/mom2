package com.momp.tasksync.parent

import android.app.Activity
import android.app.TimePickerDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var roomIn: EditText
    private lateinit var memberStatus: TextView
    private lateinit var titleIn: EditText
    private lateinit var assigneeSpinner: Spinner
    private lateinit var timeInfo: TextView
    private lateinit var taskListBox: LinearLayout

    private var members: List<Member> = emptyList()
    private var tasks: List<ParentTask> = emptyList()
    private var selectedDueMs: Long = 0L // 0 = ปลุกทันที

    @Volatile
    private var streaming = false
    private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }

    private fun btn(t: String, bg: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.textSize = 16f
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.setBackgroundColor(Color.parseColor(bg))
        b.minHeight = dp(48)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.topMargin = dp(8)
        b.layoutParams = lp
        b.setOnClickListener { f() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sv = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(36), dp(18), dp(32))
        sv.addView(col)
        setContentView(sv)

        val header = TextView(this)
        header.text = "สั่งงานลูก · เครื่องแม่"
        header.textSize = 24f
        header.setTypeface(null, Typeface.BOLD)
        col.addView(header)

        // --- ส่วนจัดการห้อง ---
        roomIn = EditText(this)
        roomIn.hint = "รหัสห้อง (เช่น ABC123)"
        roomIn.textSize = 18f
        roomIn.setSingleLine(true)
        roomIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        col.addView(roomIn)

        val roomRow = LinearLayout(this)
        roomRow.orientation = LinearLayout.HORIZONTAL
        val bCreate = btn("สร้างห้องใหม่", "#1971c2") { createRoom() }
        val bJoin = btn("เข้าห้อง", "#2f9e44") { joinRoom() }
        (bCreate.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; rightMargin = dp(6) }
        (bJoin.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; leftMargin = dp(6) }
        roomRow.addView(bCreate)
        roomRow.addView(bJoin)
        col.addView(roomRow)

        memberStatus = TextView(this)
        memberStatus.textSize = 15f
        memberStatus.setPadding(0, dp(10), 0, dp(14))
        memberStatus.text = "ยังไม่ได้เชื่อมต่อห้อง"
        col.addView(memberStatus)

        // --- ส่วนสั่งงานใหม่ ---
        val addTitle = TextView(this)
        addTitle.text = "สั่งงานใหม่"
        addTitle.textSize = 18f
        addTitle.setTypeface(null, Typeface.BOLD)
        col.addView(addTitle)

        titleIn = EditText(this)
        titleIn.hint = "พิมพ์งานที่ต้องการสั่ง เช่น ล้างจาน, ทำการบ้าน"
        titleIn.textSize = 18f
        col.addView(titleIn)

        assigneeSpinner = Spinner(this)
        col.addView(assigneeSpinner)
        updateSpinner()

        timeInfo = TextView(this)
        timeInfo.textSize = 15f
        timeInfo.setPadding(0, dp(8), 0, dp(4))
        updateTimeLabel()
        col.addView(timeInfo)

        val timeRow = LinearLayout(this)
        timeRow.orientation = LinearLayout.HORIZONTAL
        val tNow = btn("ทันที", "#495057") { selectedDueMs = 0L; updateTimeLabel() }
        val t15 = btn("+15น.", "#495057") { selectedDueMs = System.currentTimeMillis() + 15 * 60_000L; updateTimeLabel() }
        val tPick = btn("เลือกเวลา", "#495057") { pickTime() }
        for (b in listOf(tNow, t15, tPick)) {
            (b.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; rightMargin = dp(4) }
            timeRow.addView(b)
        }
        col.addView(timeRow)

        col.addView(btn("ส่งงานให้ลูก", "#e8590c") { sendTask() })

        // --- รายการงาน ---
        val listHeader = TextView(this)
        listHeader.text = "รายการงานทั้งหมด"
        listHeader.textSize = 18f
        listHeader.setTypeface(null, Typeface.BOLD)
        listHeader.setPadding(0, dp(20), 0, dp(8))
        col.addView(listHeader)

        taskListBox = LinearLayout(this)
        taskListBox.orientation = LinearLayout.VERTICAL
        col.addView(taskListBox)

        val saved = ParentStore.room(this)
        if (saved.isNotEmpty()) {
            roomIn.setText(saved)
            startListening(saved)
        }
    }

    private fun updateTimeLabel() {
        timeInfo.text = if (selectedDueMs == 0L) {
            "⏰ เวลาปลุก: ปลุกทันที"
        } else {
            "⏰ เวลาปลุก: ${timeFmt.format(Date(selectedDueMs))}"
        }
    }

    private fun pickTime() {
        val cal = Calendar.getInstance()
        TimePickerDialog(this, { _, hour, minute ->
            val target = Calendar.getInstance()
            target.set(Calendar.HOUR_OF_DAY, hour)
            target.set(Calendar.MINUTE, minute)
            target.set(Calendar.SECOND, 0)
            if (target.timeInMillis < System.currentTimeMillis()) {
                target.add(Calendar.DAY_OF_YEAR, 1)
            }
            selectedDueMs = target.timeInMillis
            updateTimeLabel()
        }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true).show()
    }

    private fun createRoom() {
        val code = ParentApi.randomCode(6)
        Thread {
            val ok = ParentApi.send("rooms/$code/meta", "PUT", "{\"createdAt\":{\".sv\":\"timestamp\"}}")
            runOnUiThread {
                if (ok) {
                    roomIn.setText(code)
                    ParentStore.setRoom(this, code)
                    toast("สร้างห้อง $code แล้ว นำรหัสนี้ไปใส่เครื่องลูกได้เลย")
                    startListening(code)
                } else {
                    toast("สร้างห้องไม่สำเร็จ ตรวจอินเทอร์เน็ต")
                }
            }
        }.start()
    }

    private fun joinRoom() {
        val code = roomIn.text.toString().trim().uppercase()
        if (code.length < 4) {
            toast("ใส่รหัสห้องอย่างน้อย 4 ตัวอักษร")
            return
        }
        Thread {
            val meta = ParentApi.get("rooms/$code/meta")
            if (meta == null) {
                runOnUiThread { toast("ต่อเน็ตไม่ได้") }
                return@Thread
            }
            if (meta == "null") {
                ParentApi.send("rooms/$code/meta", "PUT", "{\"createdAt\":{\".sv\":\"timestamp\"}}")
            }
            runOnUiThread {
                ParentStore.setRoom(this, code)
                toast("เชื่อมต่อห้อง $code แล้ว")
                startListening(code)
            }
        }.start()
    }

    private fun startListening(room: String) {
        streaming = false
        ParentApi.stopStream()
        streaming = true
        Thread {
            fetchAll(room)
            ParentApi.stream("rooms/$room", { fetchAll(room) }, { !streaming })
        }.start()
    }

    @Synchronized
    private fun fetchAll(room: String) {
        val mJson = ParentApi.get("rooms/$room/members")
        val tJson = ParentApi.get("rooms/$room/tasks")
        val newMembers = parseMembers(mJson)
        val newTasks = parseParentTasks(tJson)
        runOnUiThread {
            members = newMembers
            tasks = newTasks
            renderMembers()
            updateSpinner()
            renderTasks()
        }
    }

    private fun renderMembers() {
        val room = ParentStore.room(this)
        if (members.isEmpty()) {
            memberStatus.text = "ห้อง $room · ยังไม่มีเครื่องลูกเชื่อมต่อ"
        } else {
            val text = members.joinToString("   ") {
                (if (it.online) "🟢 " else "⚪ ") + it.name
            }
            memberStatus.text = "ห้อง $room · ลูก: $text"
        }
    }

    private fun updateSpinner() {
        val items = ArrayList<String>()
        items.add("ส่งให้: ทุกคน")
        for (m in members) items.add("ส่งให้: ${m.name}")
        val prev = assigneeSpinner.selectedItemPosition
        assigneeSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        if (prev in items.indices) assigneeSpinner.setSelection(prev)
    }

    private fun sendTask() {
        val room = ParentStore.room(this)
        if (room.isEmpty()) {
            toast("สร้างหรือเข้าห้องก่อน")
            return
        }
        val title = titleIn.text.toString().trim()
        if (title.isEmpty()) {
            toast("พิมพ์ชื่องานก่อน")
            return
        }
        val pos = assigneeSpinner.selectedItemPosition
        val assignee = if (pos > 0 && pos - 1 < members.size) members[pos - 1].id else ""
        val due = if (selectedDueMs == 0L) System.currentTimeMillis() else selectedDueMs
        val id = ParentApi.newTaskId()

        val body = JSONObject().apply {
            put("title", title)
            put("due", due)
            put("status", "pending")
            put("nudge", 0L)
            put("assignee", assignee)
        }.toString()

        Thread {
            val ok = ParentApi.send("rooms/$room/tasks/$id", "PUT", body)
            runOnUiThread {
                if (ok) {
                    titleIn.setText("")
                    selectedDueMs = 0L
                    updateTimeLabel()
                    toast("ส่งงานแล้ว")
                } else {
                    toast("ส่งงานไม่สำเร็จ")
                }
            }
        }.start()
    }

    private fun renderTasks() {
        taskListBox.removeAllViews()
        if (tasks.isEmpty()) {
            val empty = TextView(this)
            empty.text = "ยังไม่มีงานที่สั่ง"
            empty.setTextColor(Color.GRAY)
            taskListBox.addView(empty)
            return
        }
        val memberMap = members.associate { it.id to it.name }
        for (t in tasks) {
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setBackgroundColor(Color.parseColor("#f1f3f5"))
            card.setPadding(dp(14), dp(12), dp(14), dp(12))
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(10)
            card.layoutParams = lp

            val who = if (t.assignee.isEmpty()) "ทุกคน" else (memberMap[t.assignee] ?: t.assignee)
            val statusText = when (t.status) {
                "done" -> "✅ ทำเสร็จแล้ว"
                "ack" -> "👀 รับทราบแล้ว"
                else -> "⏳ รอทำ"
            }

            val tvTitle = TextView(this)
            tvTitle.text = t.title
            tvTitle.textSize = 18f
            tvTitle.setTypeface(null, Typeface.BOLD)
            card.addView(tvTitle)

            val tvSub = TextView(this)
            tvSub.text = "ถึง: $who · เวลา ${timeFmt.format(Date(t.due))} · $statusText"
            tvSub.textSize = 14f
            tvSub.setPadding(0, dp(4), 0, dp(6))
            card.addView(tvSub)

            val actRow = LinearLayout(this)
            actRow.orientation = LinearLayout.HORIZONTAL
            actRow.gravity = Gravity.END

            val bNudge = btn("🔔 ปลุกซ้ำ", "#f08c00") { nudgeTask(t.id) }
            val bDel = btn("🗑️ ลบ", "#c92a2a") { deleteTask(t.id) }
            (bNudge.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; rightMargin = dp(6) }
            (bDel.layoutParams as LinearLayout.LayoutParams).apply { width = 0; weight = 1f; leftMargin = dp(6) }
            actRow.addView(bNudge)
            actRow.addView(bDel)
            card.addView(actRow)

            taskListBox.addView(card)
        }
    }

    private fun nudgeTask(id: String) {
        val room = ParentStore.room(this)
        val body = "{\"status\":\"pending\",\"nudge\":${System.currentTimeMillis()}}"
        Thread {
            val ok = ParentApi.send("rooms/$room/tasks/$id", "PATCH", body)
            runOnUiThread { toast(if (ok) "ส่งสัญญาณปลุกซ้ำแล้ว" else "ปลุกซ้ำไม่สำเร็จ") }
        }.start()
    }

    private fun deleteTask(id: String) {
        val room = ParentStore.room(this)
        Thread {
            val ok = ParentApi.send("rooms/$room/tasks/$id", "DELETE")
            runOnUiThread { toast(if (ok) "ลบงานแล้ว" else "ลบไม่สำเร็จ") }
        }.start()
    }

    override fun onDestroy() {
        streaming = false
        ParentApi.stopStream()
        super.onDestroy()
    }
}
